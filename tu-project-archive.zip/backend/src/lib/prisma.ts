import { PrismaClient } from '@prisma/client';
import { isProd } from '../config/env.js';

/**
 * Single PrismaClient instance (avoids exhausting DB connections on hot-reload).
 */
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: isProd ? ['error'] : ['warn', 'error'],
  });

if (!isProd) globalForPrisma.prisma = prisma;
