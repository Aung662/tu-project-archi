'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import type { AuditEntry } from '@/lib/types';
import { Spinner, EmptyState } from '@/components/ui';
import { tr, t } from '@/lib/i18n';

export default function AdminAudit() {
  const [logs, setLogs] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get<AuditEntry[]>('/admin/audit')
      .then(setLogs)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner />;
  if (logs.length === 0) return <EmptyState title={tr(t.auEmpty)} />;

  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-white/5 text-left text-xs uppercase text-slate-400">
          <tr>
            <th className="px-4 py-3">{tr(t.auColWhen)}</th>
            <th className="px-4 py-3">{tr(t.auColActor)}</th>
            <th className="px-4 py-3">{tr(t.auColAction)}</th>
            <th className="px-4 py-3">{tr(t.auColEntity)}</th>
            <th className="px-4 py-3">Details</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/10">
          {logs.map((l) => (
            <tr key={l.id}>
              <td className="whitespace-nowrap px-4 py-3 text-slate-400">
                {new Date(l.createdAt).toLocaleString()}
              </td>
              <td className="px-4 py-3">{l.actor?.name ?? 'system'}</td>
              <td className="px-4 py-3">
                <span className="badge bg-white/10 font-mono text-slate-200">{l.action}</span>
              </td>
              <td className="px-4 py-3 text-xs text-slate-400">
                {l.entityType}:{l.entityId.slice(0, 8)}
              </td>
              <td className="max-w-xs truncate px-4 py-3 text-xs text-slate-400">{l.metadata}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
