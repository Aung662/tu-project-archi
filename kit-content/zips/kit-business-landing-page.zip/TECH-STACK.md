# Business / Startup Landing Page — Tech Stack & Alternatives

## Recommended (in this kit)
- **Next.js**
- **React**
- **Tailwind CSS**

## Why this stack
One page, blazing fast, great SEO, and free hosting — ideal for ads/landing traffic.

## Beginner-friendly alternative
A no-build **HTML + Tailwind CDN** single file. Great for a quick campaign page.

## Scale-up alternative
Add **A/B testing** (Vercel/PostHog) and a CMS (Sanity) so marketing can edit copy without code.

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
