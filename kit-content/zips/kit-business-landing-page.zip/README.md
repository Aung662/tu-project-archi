# Business / Startup Landing Page

A high-converting one-page site to explain a product or service and capture leads.

**မြန်မာ:** ကုန်ပစ္စည်း/ဝန်ဆောင်မှုကို ရှင်းပြပြီး customer lead တွေ ဖမ်းယူဖို့ one-page landing site။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
