# Business / Startup Landing Page — Printable Checklist

## Plan
- [ ] Goal written in one sentence
- [ ] Page list finalised: Hero, Features, Pricing, FAQ, Contact / CTA
- [ ] Real content gathered (text + images)
- [ ] Colour + font chosen

## Build
- [ ] Project created and dev server runs
- [ ] Shared layout (header/nav/footer)
- [ ] Every page built
- [ ] Styled, mobile-first
- [ ] Data/interactivity working

## Quality
- [ ] Accessible (alt text, labels, focus, semantic HTML)
- [ ] SEO (titles, meta, Open Graph)
- [ ] Images compressed
- [ ] Lighthouse ≥ 90 ×4
- [ ] Tested on a real phone

## Launch
- [ ] Deployed to Vercel
- [ ] Custom domain (optional)
- [ ] Favicon + social image
- [ ] Analytics installed
- [ ] 404 page
- [ ] Main task tested by a stranger
