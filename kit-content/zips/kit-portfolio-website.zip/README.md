# Personal Portfolio Website

A fast, elegant personal/portfolio site to showcase your projects, CV and contact.

**မြန်မာ:** ကိုယ်ပိုင် project၊ CV နဲ့ ဆက်သွယ်ရန် အချက်အလက်တွေ ပြသဖို့ လှပမြန်ဆန်တဲ့ portfolio site။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
