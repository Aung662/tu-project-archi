# Personal Portfolio Website — Tech Stack & Alternatives

## Recommended (in this kit)
- **Next.js**
- **React**
- **Tailwind CSS**

## Why this stack
Next.js gives instant page loads, easy routing and free Vercel hosting. Tailwind makes consistent styling fast.

## Beginner-friendly alternative
Plain **HTML + CSS + a little JavaScript** — perfect if you want zero build tools. Host on GitHub Pages.

## Scale-up alternative
Add **MDX** for a blog, or **Astro** if the site is mostly content and you want the lightest possible output.

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
