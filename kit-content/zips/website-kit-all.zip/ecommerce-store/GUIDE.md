# E-Commerce Store — Step-by-Step Build Guide

> An online store with a product catalog, cart and checkout.
>
> **မြန်မာ:** ကုန်ပစ္စည်းစာရင်း၊ cart နဲ့ checkout ပါဝင်တဲ့ online ဆိုင်။

**Difficulty:** Advanced · **Est. time:** 3–5 days · **Stack:** Next.js, React, Tailwind CSS, Stripe, Supabase

---

## 0. Before you start (Prerequisites)

Install these once:

- **Node.js LTS** (v20+) — https://nodejs.org  → verify: `node -v`
- **Git** — https://git-scm.com  → verify: `git --version`
- **VS Code** — https://code.visualstudio.com
- A **GitHub** account (free) and a **Vercel** or **Netlify** account (free hosting)
- A **Stripe** account (test mode is free)
- A **Supabase** project (free) for products & orders

> မြန်မာ: အထက်ပါ tool တွေကို အရင် install လုပ်ပါ။ terminal ထဲမှာ `node -v` ရိုက်ပြီး version ပေါ်ရင် အဆင်ပြေပါပြီ။

---

## 1. Plan the site (30 minutes, do NOT skip)

Write down, in one page:

1. **Goal** — what should a visitor be able to DO? (let a customer find a product, add it to a cart, and pay)
2. **Pages** — Home · Catalog · Product detail · Cart · Checkout · Order confirmation
3. **Content** — the real text/images you will show (gather them into a folder now).
4. **Brand** — 1 primary colour, 1 accent, 1 font. Keep it simple.

> Use **PROMPTS.md → Prompt 1** to have an AI turn this into a spec.

---

## 2. Create the project

```bash
npx create-next-app@latest my-store --ts --tailwind --eslint --app
cd my-store
npm install @supabase/supabase-js stripe
```

Open the folder in VS Code and run the dev server:

```bash
npm run dev
```

Visit **http://localhost:3000** — you should see the starter page.

---

## 3. Build the layout & pages

- Create the shared **layout** (header, nav, footer) first.
- Add each page from your plan as a route.
- Keep components small and reusable (a `Button`, a `Card`, a `Section`).

> Use **PROMPTS.md → Prompt 2 & 3** to scaffold the layout and each page.

- **Catalog:** filterable/paginated product grid from the database.
- **Product detail:** gallery, price, variants, add-to-cart.
- **Cart:** stored in local storage + server validation.
- **Checkout:** Stripe Checkout (never handle raw card data yourself).

---

## 4. Style it

- Start mobile-first; test at 375px width, then widen.
- Use the design tokens from your plan (one colour scale, consistent spacing).
- Add hover/focus states and smooth transitions — small touches read as "polished".

> Use **PROMPTS.md → Prompt 4** for a full styling pass.

---

## 5. Make it real (data & interactivity)

- Model `products`, `orders`, `order_items` in Supabase.
- Use **Stripe Checkout** for payment — it is PCI-compliant and free to start.
- Verify the order server-side via a **Stripe webhook** before marking it paid.

> Security: keep the Stripe **secret key** on the server only (env var). Never in client code.

> Use **PROMPTS.md → Prompt 5** for the data/logic layer.

---

## 6. Quality pass (accessibility, SEO, performance)

- **Accessibility:** semantic HTML, alt text on images, labels on inputs, visible focus.
- **SEO:** a unique `<title>` + meta description per page; Open Graph tags for sharing.
- **Performance:** compress images (WebP), lazy-load below-the-fold media, avoid huge JS.
- Run **Lighthouse** in Chrome DevTools → aim for 90+ on all four scores.

> Use **PROMPTS.md → Prompt 6** for an automated audit checklist.

---

## 7. Test

- Click every link and button. Submit every form with good AND bad input.
- Test on a real phone (open your dev URL on the same Wi-Fi, or deploy a preview).
- Ask one person who has never seen it to complete the main task.

---

## 8. Deploy (free)

```bash
git init && git add -A && git commit -m "first version"
# create an empty repo on GitHub, then:
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

Then import the repo on **Vercel** (add your env vars in the Vercel dashboard). Every future `git push` auto-deploys.

> Use **PROMPTS.md → Prompt 7** for a deployment checklist and troubleshooting.

---

## 9. Launch checklist

- [ ] Custom domain connected (optional)
- [ ] Favicon + social share image set
- [ ] Analytics added (Plausible/Umami/GA)
- [ ] 404 page exists
- [ ] Contact route works and you receive a test message
- [ ] Lighthouse ≥ 90 across the board

🎉 **Done!** You have a live e-commerce store.

---

_This guide is part of the TU Project Archive Website Kit. See PROMPTS.md for the full AI prompt pack, TECH-STACK.md for alternatives, and CHECKLIST.md for a printable version._
