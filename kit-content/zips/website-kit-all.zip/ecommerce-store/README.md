# E-Commerce Store

An online store with a product catalog, cart and checkout.

**မြန်မာ:** ကုန်ပစ္စည်းစာရင်း၊ cart နဲ့ checkout ပါဝင်တဲ့ online ဆိုင်။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
