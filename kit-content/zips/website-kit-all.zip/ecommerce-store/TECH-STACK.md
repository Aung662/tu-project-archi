# E-Commerce Store — Tech Stack & Alternatives

## Recommended (in this kit)
- **Next.js**
- **React**
- **Tailwind CSS**
- **Stripe**
- **Supabase**

## Why this stack
Next.js server routes keep payment secrets safe; Stripe handles compliance; Supabase gives a free Postgres DB with auth.

## Beginner-friendly alternative
Use **Shopify** or **Gumroad** if you want to sell fast without building checkout. Or a static store with **Snipcart**.

## Scale-up alternative
Move to **Medusa** or **Saleor** (open-source commerce engines) when you outgrow a single Stripe flow.

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
