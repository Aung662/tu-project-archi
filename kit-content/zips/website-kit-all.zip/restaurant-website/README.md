# Restaurant / Cafe Website

A menu-driven site with photos, hours, location and online reservations.

**မြန်မာ:** menu၊ ဓာတ်ပုံ၊ ဖွင့်ချိန်၊ တည်နေရာ နဲ့ online booking ပါတဲ့ စားသောက်ဆိုင် website။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
