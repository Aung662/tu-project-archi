# Restaurant / Cafe Website — Tech Stack & Alternatives

## Recommended (in this kit)
- **Next.js**
- **React**
- **Tailwind CSS**

## Why this stack
Fast, image-friendly, and free to host — perfect for a mostly-static local business site.

## Beginner-friendly alternative
A single-page **HTML + Tailwind CDN** site, or a **Google Sites** page for the absolute simplest option.

## Scale-up alternative
Add an ordering/payment flow (Stripe) or a CMS so staff can update the menu without code.

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
