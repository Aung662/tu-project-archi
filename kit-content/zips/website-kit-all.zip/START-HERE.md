# 👋 Start Here

Welcome! You just unlocked the **TU Project Archive Website Kit**.

**Step 1:** Open **README.md** for the full index of 8 website types.

**Step 2:** Not sure which to pick?

| If you want to… | Build this |
|---|---|
| Show your work / get hired | Personal Portfolio Website |
| Launch a product & collect leads | Business / Startup Landing Page |
| Sell products online | E-Commerce Store |
| Publish articles | Blog / Content Website |
| Manage data internally | Admin Dashboard |
| Promote a restaurant/cafe | Restaurant / Cafe Website |
| Charge a monthly subscription | SaaS Web App |
| Run an event | Event / Conference Website |

**Step 3:** Open that folder → read **GUIDE.md** → keep **PROMPTS.md** beside it.

Happy building! 🚀
