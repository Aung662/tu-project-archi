# 🌐 TU Project Archive — Website Building Kit

A complete, beginner-friendly toolkit for building 8 common website types.
Each type has a step-by-step guide **and** a full pack of copy-paste AI prompts, so
you can go from idea to a deployed site — even if you are new to web development.

> မြန်မာ: ဒီ kit ထဲမှာ website အမျိုးအစား 8 မျိုးအတွက် အစအဆုံး လမ်းညွှန်ချက်တွေနဲ့
> AI prompt အပြည့်အစုံ ပါဝင်ပါတယ်။ web development အသစ်စတင်သူတွေလည်း အသုံးပြုနိုင်ပါတယ်။

## What's inside

1. **Personal Portfolio Website** `/portfolio-website` — A fast, elegant personal/portfolio site to showcase your projects, CV and contact.
2. **Business / Startup Landing Page** `/business-landing-page` — A high-converting one-page site to explain a product or service and capture leads.
3. **E-Commerce Store** `/ecommerce-store` — An online store with a product catalog, cart and checkout.
4. **Blog / Content Website** `/blog-cms` — A content site or blog with articles, categories and SEO built in.
5. **Admin Dashboard / Analytics Panel** `/admin-dashboard` — A data dashboard with tables, charts, auth and CRUD for an internal tool.
6. **Restaurant / Cafe Website** `/restaurant-website` — A menu-driven site with photos, hours, location and online reservations.
7. **SaaS Web App (Auth + Subscriptions)** `/saas-web-app` — A subscription web app with user accounts, a dashboard and billing.
8. **Event / Conference Website** `/event-conference-website` — A site for an event: schedule, speakers, tickets/registration and venue info.

## How to use this kit

1. Pick the website type closest to what you want to build.
2. Open that folder and read **GUIDE.md** top to bottom.
3. Keep **PROMPTS.md** open — paste each prompt into your AI assistant as you reach that step.
4. Use **CHECKLIST.md** to make sure you didn't miss anything before launch.

## What you need (all free to start)

- A computer with **Node.js** and **Git** installed
- **VS Code** (or any editor)
- A **GitHub** account and a **Vercel/Netlify** account for free hosting
- An **AI assistant** (ChatGPT, Claude, Gemini, or Cursor/Copilot in your editor)

## Golden rules

- **Ship small, ship often.** Get one page live, then improve.
- **Never paste code you don't understand** — ask the AI to explain it.
- **Keep secrets server-side.** API keys never belong in client code or Git.
- **Test on a real phone** before you call it done.

---

_© TU Project Archive Website Kit. For personal & educational use by the purchaser._
