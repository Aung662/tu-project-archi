# SaaS Web App (Auth + Subscriptions) — Tech Stack & Alternatives

## Recommended (in this kit)
- **Next.js**
- **React**
- **Tailwind CSS**
- **Supabase**
- **Stripe**

## Why this stack
This is the standard modern SaaS stack: Next.js app + Supabase (auth/DB) + Stripe (subscriptions), all with free starting tiers.

## Beginner-friendly alternative
Start from an open-source **SaaS starter** (e.g. a Next.js + Supabase + Stripe template) and customise.

## Scale-up alternative
Introduce a queue (Inngest), transactional email (Resend), and per-tenant Postgres schemas as you grow.

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
