# SaaS Web App (Auth + Subscriptions) — Step-by-Step Build Guide

> A subscription web app with user accounts, a dashboard and billing.
>
> **မြန်မာ:** user account၊ dashboard နဲ့ subscription billing ပါတဲ့ SaaS web app။

**Difficulty:** Advanced · **Est. time:** 5–7 days · **Stack:** Next.js, React, Tailwind CSS, Supabase, Stripe

---

## 0. Before you start (Prerequisites)

Install these once:

- **Node.js LTS** (v20+) — https://nodejs.org  → verify: `node -v`
- **Git** — https://git-scm.com  → verify: `git --version`
- **VS Code** — https://code.visualstudio.com
- A **GitHub** account (free) and a **Vercel** or **Netlify** account (free hosting)
- A **Supabase** project (auth + DB)
- A **Stripe** account with a subscription Product/Price

> မြန်မာ: အထက်ပါ tool တွေကို အရင် install လုပ်ပါ။ terminal ထဲမှာ `node -v` ရိုက်ပြီး version ပေါ်ရင် အဆင်ပြေပါပြီ။

---

## 1. Plan the site (30 minutes, do NOT skip)

Write down, in one page:

1. **Goal** — what should a visitor be able to DO? (let users sign up, use a gated feature, and pay a recurring subscription)
2. **Pages** — Marketing home · Sign up / Login · App dashboard · Billing · Account settings
3. **Content** — the real text/images you will show (gather them into a folder now).
4. **Brand** — 1 primary colour, 1 accent, 1 font. Keep it simple.

> Use **PROMPTS.md → Prompt 1** to have an AI turn this into a spec.

---

## 2. Create the project

```bash
npx create-next-app@latest my-saas --ts --tailwind --eslint --app
cd my-saas
npm install @supabase/supabase-js stripe
```

Open the folder in VS Code and run the dev server:

```bash
npm run dev
```

Visit **http://localhost:3000** — you should see the starter page.

---

## 3. Build the layout & pages

- Create the shared **layout** (header, nav, footer) first.
- Add each page from your plan as a route.
- Keep components small and reusable (a `Button`, a `Card`, a `Section`).

> Use **PROMPTS.md → Prompt 2 & 3** to scaffold the layout and each page.

- **Auth:** email/OAuth login via Supabase; protect all `/app` routes server-side.
- **Gating:** check subscription status before serving paid features.
- **Billing:** Stripe Checkout for subscriptions + a Customer Portal for self-service.
- **Webhooks:** sync subscription status from Stripe → your DB.

---

## 4. Style it

- Start mobile-first; test at 375px width, then widen.
- Use the design tokens from your plan (one colour scale, consistent spacing).
- Add hover/focus states and smooth transitions — small touches read as "polished".

> Use **PROMPTS.md → Prompt 4** for a full styling pass.

---

## 5. Make it real (data & interactivity)

- Tables: `profiles`, `subscriptions`. Update `subscriptions` from Stripe webhooks.
- Gate features by reading the current subscription server-side (never trust the client).

> Security: verify Stripe webhook signatures; keep secret keys server-side; enforce plan limits on the server.

> Use **PROMPTS.md → Prompt 5** for the data/logic layer.

---

## 6. Quality pass (accessibility, SEO, performance)

- **Accessibility:** semantic HTML, alt text on images, labels on inputs, visible focus.
- **SEO:** a unique `<title>` + meta description per page; Open Graph tags for sharing.
- **Performance:** compress images (WebP), lazy-load below-the-fold media, avoid huge JS.
- Run **Lighthouse** in Chrome DevTools → aim for 90+ on all four scores.

> Use **PROMPTS.md → Prompt 6** for an automated audit checklist.

---

## 7. Test

- Click every link and button. Submit every form with good AND bad input.
- Test on a real phone (open your dev URL on the same Wi-Fi, or deploy a preview).
- Ask one person who has never seen it to complete the main task.

---

## 8. Deploy (free)

```bash
git init && git add -A && git commit -m "first version"
# create an empty repo on GitHub, then:
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

Then import the repo on **Vercel** (configure Supabase + Stripe env vars and the webhook URL). Every future `git push` auto-deploys.

> Use **PROMPTS.md → Prompt 7** for a deployment checklist and troubleshooting.

---

## 9. Launch checklist

- [ ] Custom domain connected (optional)
- [ ] Favicon + social share image set
- [ ] Analytics added (Plausible/Umami/GA)
- [ ] 404 page exists
- [ ] Contact route works and you receive a test message
- [ ] Lighthouse ≥ 90 across the board

🎉 **Done!** You have a live saas web app (auth + subscriptions).

---

_This guide is part of the TU Project Archive Website Kit. See PROMPTS.md for the full AI prompt pack, TECH-STACK.md for alternatives, and CHECKLIST.md for a printable version._
