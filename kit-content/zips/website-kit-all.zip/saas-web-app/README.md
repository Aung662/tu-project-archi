# SaaS Web App (Auth + Subscriptions)

A subscription web app with user accounts, a dashboard and billing.

**မြန်မာ:** user account၊ dashboard နဲ့ subscription billing ပါတဲ့ SaaS web app။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
