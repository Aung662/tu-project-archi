# SaaS Web App (Auth + Subscriptions) — AI Prompt Pack

Copy each prompt into your AI assistant (ChatGPT, Claude, Gemini, or an in-editor
tool like Cursor/Copilot). Replace `{{...}}` placeholders with your real details.
Prompts are ordered to match the build guide steps.

> မြန်မာ: အောက်ပါ prompt တွေကို AI assistant ထဲ ကူးထည့်ပါ။ `{{...}}` နေရာတွေမှာ
> ကိုယ့်အချက်အလက် အစားထိုးပါ။ တစ်ဆင့်ချင်း အစဉ်လိုက် လုပ်သွားပါ။

---

## Prompt 1 — Turn my idea into a spec

```
You are a senior product designer. I am building a saas web app (auth + subscriptions).
Goal: let users sign up, use a gated feature, and pay a recurring subscription
Audience: {{who will use this}}
Must-have pages: Marketing home, Sign up / Login, App dashboard, Billing, Account settings
Brand feeling: {{e.g. modern, trustworthy, playful}}

Produce:
1. A one-paragraph product summary.
2. A sitemap (pages + what each contains).
3. A component list (reusable UI pieces).
4. A colour palette (hex) + font pairing suitable for the brand feeling.
5. The single most important call-to-action per page.
Keep it concise and practical.
```

## Prompt 2 — Scaffold the project & layout

```
Create a Next.js project structure for a saas web app (auth + subscriptions) using Next.js + React + Tailwind CSS + Supabase + Stripe.
Give me:
- the exact terminal commands to create it,
- the folder structure,
- a shared layout with a responsive header (logo + nav + mobile menu) and a footer,
- routing set up for these pages: Marketing home, Sign up / Login, App dashboard, Billing, Account settings.
Use accessible, semantic HTML and mobile-first CSS. Return complete file contents.
```

## Prompt 3 — Build a specific page

```
Build the "{{page name}}" page for my saas web app (auth + subscriptions).
It should contain: {{list the sections/content}}.
Match this design language: {{paste palette + font from Prompt 1}}.
Requirements: responsive, accessible, fast. Reuse my existing components where possible.
Return the full page file plus any new components.
```

## Prompt 4 — Styling & polish pass

```
Here is my page code:
{{paste code}}
Improve the visual design WITHOUT changing the content or breaking functionality:
- consistent spacing scale and typography,
- clear visual hierarchy,
- hover/focus/active states and subtle transitions,
- dark-mode support if easy.
Explain each change briefly, then return the updated code.
```

## Prompt 5 — Auth + subscription gating + Stripe billing

```
Build the core of a SaaS app with Next.js, Supabase Auth and Stripe subscriptions:
1. server-side auth guard for /app routes,
2. Stripe Checkout to start a subscription and a Customer Portal link,
3. a webhook that upserts subscription status into a `subscriptions` table,
4. a server helper `getActiveSubscription(userId)` used to gate a paid feature.
Verify webhook signatures and keep secrets server-side. Return complete files.
```

## Prompt 6 — Accessibility, SEO & performance audit

```
Audit this page for accessibility (WCAG AA), SEO, and performance:
{{paste code}}
Return a prioritised checklist (High/Medium/Low) with the exact code fix for each item.
Include per-page <title> and meta description suggestions and Open Graph tags.
```

## Prompt 7 — Deploy & troubleshoot

```
I want to deploy my Next.js app for free.
Walk me through deploying to Vercel step by step, including:
- connecting my GitHub repo,
- environment variables I need (if any),
- custom domain setup,
- and the 3 most common deploy errors for this stack with fixes.
```

## Prompt 8 — Content & copywriting

```
Write the on-page copy for my saas web app (auth + subscriptions).
Business/subject: {{describe}}
Tone: {{friendly / professional / bold}}
Language: {{English / Burmese / both}}
For each page (Marketing home, Sign up / Login, App dashboard, Billing, Account settings) give: a headline, a supporting sentence,
and the primary button label. Keep it concrete and benefit-led.
```

## Bonus — Pricing strategy

```
Suggest a 3-tier pricing model for {{product}} targeting {{audience}}.
For each tier: name, monthly price, included limits, and the one feature that
justifies upgrading. Explain the psychology briefly.
```

## Bonus — Webhook security check

```
Review my Stripe webhook handler for missing signature verification, replay
protection, and idempotency. {{paste code}} Return exact fixes.
```

---

_Tip: after each prompt, paste the AI's output into your editor, run it, and fix
one error at a time. Never paste code you don't understand — ask the AI to explain._
