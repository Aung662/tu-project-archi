# Event / Conference Website — Tech Stack & Alternatives

## Recommended (in this kit)
- **Next.js**
- **React**
- **Tailwind CSS**

## Why this stack
Content is mostly fixed until the event, so a fast static-ish Next.js site is cheap, reliable under launch-day traffic, and free to host.

## Beginner-friendly alternative
Use **Luma** or **Eventbrite** for registration + a simple one-page site linking to them.

## Scale-up alternative
Add a CMS (Sanity) so organisers update the agenda live, and a check-in app for the door.

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
