# Event / Conference Website

A site for an event: schedule, speakers, tickets/registration and venue info.

**မြန်မာ:** အစီအစဉ်၊ speaker များ၊ ticket/registration နဲ့ venue အချက်အလက် ပါတဲ့ event website။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
