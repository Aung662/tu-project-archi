# Blog / Content Website

A content site or blog with articles, categories and SEO built in.

**မြန်မာ:** ဆောင်းပါး၊ category နဲ့ SEO ပါဝင်တဲ့ blog / content website။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
