# Blog / Content Website — Tech Stack & Alternatives

## Recommended (in this kit)
- **Astro**
- **Markdown/MDX**
- **Tailwind CSS**

## Why this stack
Astro ships almost no JavaScript, so content sites are extremely fast and SEO-friendly, and Markdown is the easiest way to write.

## Beginner-friendly alternative
Use **Hashnode** or **WordPress.com** if you just want to write and not maintain code.

## Scale-up alternative
Switch to **Next.js + a headless CMS** if you need dynamic features (comments, member areas, search).

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
