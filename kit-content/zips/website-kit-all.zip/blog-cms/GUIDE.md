# Blog / Content Website — Step-by-Step Build Guide

> A content site or blog with articles, categories and SEO built in.
>
> **မြန်မာ:** ဆောင်းပါး၊ category နဲ့ SEO ပါဝင်တဲ့ blog / content website။

**Difficulty:** Intermediate · **Est. time:** 2–3 days · **Stack:** Astro, Markdown/MDX, Tailwind CSS

---

## 0. Before you start (Prerequisites)

Install these once:

- **Node.js LTS** (v20+) — https://nodejs.org  → verify: `node -v`
- **Git** — https://git-scm.com  → verify: `git --version`
- **VS Code** — https://code.visualstudio.com
- A **GitHub** account (free) and a **Vercel** or **Netlify** account (free hosting)


> မြန်မာ: အထက်ပါ tool တွေကို အရင် install လုပ်ပါ။ terminal ထဲမှာ `node -v` ရိုက်ပြီး version ပေါ်ရင် အဆင်ပြေပါပြီ။

---

## 1. Plan the site (30 minutes, do NOT skip)

Write down, in one page:

1. **Goal** — what should a visitor be able to DO? (publish readable, discoverable articles quickly)
2. **Pages** — Home (post list) · Post detail · Category/Tag · About · RSS feed
3. **Content** — the real text/images you will show (gather them into a folder now).
4. **Brand** — 1 primary colour, 1 accent, 1 font. Keep it simple.

> Use **PROMPTS.md → Prompt 1** to have an AI turn this into a spec.

---

## 2. Create the project

```bash
npm create astro@latest my-blog
cd my-blog
npx astro add tailwind mdx sitemap
```

Open the folder in VS Code and run the dev server:

```bash
npm run dev
```

Visit **http://localhost:4321** — you should see the starter page.

---

## 3. Build the layout & pages

- Create the shared **layout** (header, nav, footer) first.
- Add each page from your plan as a route.
- Keep components small and reusable (a `Button`, a `Card`, a `Section`).

> Use **PROMPTS.md → Prompt 2 & 3** to scaffold the layout and each page.

- Write posts as **Markdown/MDX** files with frontmatter (title, date, tags, cover).
- Generate the post list, tag pages, and RSS automatically from the files.
- Add a reading-time estimate and a table of contents for long posts.

---

## 4. Style it

- Start mobile-first; test at 375px width, then widen.
- Use the design tokens from your plan (one colour scale, consistent spacing).
- Add hover/focus states and smooth transitions — small touches read as "polished".

> Use **PROMPTS.md → Prompt 4** for a full styling pass.

---

## 5. Make it real (data & interactivity)

- No database — posts are files in `src/content/`. Astro type-checks the frontmatter.
- Optionally connect a headless CMS (**Sanity**, **Decap/Netlify CMS**) so non-devs can write.

> Use **PROMPTS.md → Prompt 5** for the data/logic layer.

---

## 6. Quality pass (accessibility, SEO, performance)

- **Accessibility:** semantic HTML, alt text on images, labels on inputs, visible focus.
- **SEO:** a unique `<title>` + meta description per page; Open Graph tags for sharing.
- **Performance:** compress images (WebP), lazy-load below-the-fold media, avoid huge JS.
- Run **Lighthouse** in Chrome DevTools → aim for 90+ on all four scores.

> Use **PROMPTS.md → Prompt 6** for an automated audit checklist.

---

## 7. Test

- Click every link and button. Submit every form with good AND bad input.
- Test on a real phone (open your dev URL on the same Wi-Fi, or deploy a preview).
- Ask one person who has never seen it to complete the main task.

---

## 8. Deploy (free)

```bash
git init && git add -A && git commit -m "first version"
# create an empty repo on GitHub, then:
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

Then import the repo on **Vercel** (Astro outputs static files — deploys anywhere). Every future `git push` auto-deploys.

> Use **PROMPTS.md → Prompt 7** for a deployment checklist and troubleshooting.

---

## 9. Launch checklist

- [ ] Custom domain connected (optional)
- [ ] Favicon + social share image set
- [ ] Analytics added (Plausible/Umami/GA)
- [ ] 404 page exists
- [ ] Contact route works and you receive a test message
- [ ] Lighthouse ≥ 90 across the board

🎉 **Done!** You have a live blog / content website.

---

_This guide is part of the TU Project Archive Website Kit. See PROMPTS.md for the full AI prompt pack, TECH-STACK.md for alternatives, and CHECKLIST.md for a printable version._
