# Blog / Content Website — AI Prompt Pack

Copy each prompt into your AI assistant (ChatGPT, Claude, Gemini, or an in-editor
tool like Cursor/Copilot). Replace `{{...}}` placeholders with your real details.
Prompts are ordered to match the build guide steps.

> မြန်မာ: အောက်ပါ prompt တွေကို AI assistant ထဲ ကူးထည့်ပါ။ `{{...}}` နေရာတွေမှာ
> ကိုယ့်အချက်အလက် အစားထိုးပါ။ တစ်ဆင့်ချင်း အစဉ်လိုက် လုပ်သွားပါ။

---

## Prompt 1 — Turn my idea into a spec

```
You are a senior product designer. I am building a blog / content website.
Goal: publish readable, discoverable articles quickly
Audience: {{who will use this}}
Must-have pages: Home (post list), Post detail, Category/Tag, About, RSS feed
Brand feeling: {{e.g. modern, trustworthy, playful}}

Produce:
1. A one-paragraph product summary.
2. A sitemap (pages + what each contains).
3. A component list (reusable UI pieces).
4. A colour palette (hex) + font pairing suitable for the brand feeling.
5. The single most important call-to-action per page.
Keep it concise and practical.
```

## Prompt 2 — Scaffold the project & layout

```
Create a Astro project structure for a blog / content website using Astro + Markdown/MDX + Tailwind CSS.
Give me:
- the exact terminal commands to create it,
- the folder structure,
- a shared layout with a responsive header (logo + nav + mobile menu) and a footer,
- routing set up for these pages: Home (post list), Post detail, Category/Tag, About, RSS feed.
Use accessible, semantic HTML and mobile-first CSS. Return complete file contents.
```

## Prompt 3 — Build a specific page

```
Build the "{{page name}}" page for my blog / content website.
It should contain: {{list the sections/content}}.
Match this design language: {{paste palette + font from Prompt 1}}.
Requirements: responsive, accessible, fast. Reuse my existing components where possible.
Return the full page file plus any new components.
```

## Prompt 4 — Styling & polish pass

```
Here is my page code:
{{paste code}}
Improve the visual design WITHOUT changing the content or breaking functionality:
- consistent spacing scale and typography,
- clear visual hierarchy,
- hover/focus/active states and subtle transitions,
- dark-mode support if easy.
Explain each change briefly, then return the updated code.
```

## Prompt 5 — Content collection + RSS

```
Set up an Astro content collection for blog posts with a typed frontmatter
schema (title, description, date, tags, cover, draft). Generate: the post list
sorted by date, individual post pages, tag archive pages, and an RSS feed.
Return complete files.
```

## Prompt 6 — Accessibility, SEO & performance audit

```
Audit this page for accessibility (WCAG AA), SEO, and performance:
{{paste code}}
Return a prioritised checklist (High/Medium/Low) with the exact code fix for each item.
Include per-page <title> and meta description suggestions and Open Graph tags.
```

## Prompt 7 — Deploy & troubleshoot

```
I want to deploy my Astro app for free.
Walk me through deploying to Netlify or Vercel step by step, including:
- connecting my GitHub repo,
- environment variables I need (if any),
- custom domain setup,
- and the 3 most common deploy errors for this stack with fixes.
```

## Prompt 8 — Content & copywriting

```
Write the on-page copy for my blog / content website.
Business/subject: {{describe}}
Tone: {{friendly / professional / bold}}
Language: {{English / Burmese / both}}
For each page (Home (post list), Post detail, Category/Tag, About, RSS feed) give: a headline, a supporting sentence,
and the primary button label. Keep it concrete and benefit-led.
```

## Bonus — Outline + draft

```
Write a blog post outline then a first draft on "{{topic}}" for {{audience}}.
Include an SEO title, meta description, H2/H3 structure, and a key-takeaways box.
Target ~{{word count}} words. Language: {{English/Burmese}}.
```

---

_Tip: after each prompt, paste the AI's output into your editor, run it, and fix
one error at a time. Never paste code you don't understand — ask the AI to explain._
