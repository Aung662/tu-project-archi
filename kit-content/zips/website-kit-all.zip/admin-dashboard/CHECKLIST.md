# Admin Dashboard / Analytics Panel — Printable Checklist

## Plan
- [ ] Goal written in one sentence
- [ ] Page list finalised: Login, Overview (KPIs + charts), Records (table + CRUD), Settings
- [ ] Real content gathered (text + images)
- [ ] Colour + font chosen

## Build
- [ ] Project created and dev server runs
- [ ] Shared layout (header/nav/footer)
- [ ] Every page built
- [ ] Styled, mobile-first
- [ ] Data/interactivity working

## Quality
- [ ] Accessible (alt text, labels, focus, semantic HTML)
- [ ] SEO (titles, meta, Open Graph)
- [ ] Images compressed
- [ ] Lighthouse ≥ 90 ×4
- [ ] Tested on a real phone

## Launch
- [ ] Deployed to Vercel
- [ ] Custom domain (optional)
- [ ] Favicon + social image
- [ ] Analytics installed
- [ ] 404 page
- [ ] Main task tested by a stranger
