# Admin Dashboard / Analytics Panel — Tech Stack & Alternatives

## Recommended (in this kit)
- **Next.js**
- **React**
- **Tailwind CSS**
- **Supabase**
- **Recharts**

## Why this stack
Next.js server components keep queries and auth on the server; Supabase gives auth + Postgres + RLS for free; Recharts is simple and responsive.

## Beginner-friendly alternative
Use **Retool** or **Appsmith** to drag-and-drop an internal tool with no frontend code.

## Scale-up alternative
Adopt **tRPC** or a typed API layer and a dedicated Postgres (Neon) as data and team size grow.

## Free services you'll likely use
- **Hosting:** Vercel, Netlify, or Cloudflare Pages (all have generous free tiers)
- **Database (if needed):** Supabase, Neon, or Firebase (free tiers)
- **Forms/email:** Formspree, Resend, or EmailJS
- **Analytics:** Plausible (self-host), Umami, or Google Analytics
- **Images:** Cloudinary or built-in image optimisation

> မြန်မာ: အခမဲ့ tier တွေနဲ့ စတင်နိုင်ပါတယ်။ Traffic များလာမှ paid သို့ တိုးမြှင့်ပါ။
