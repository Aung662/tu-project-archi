# Admin Dashboard / Analytics Panel

A data dashboard with tables, charts, auth and CRUD for an internal tool.

**မြန်မာ:** table၊ chart၊ login နဲ့ CRUD ပါဝင်တဲ့ internal admin dashboard။

This folder contains everything you need to build this website type:

- **GUIDE.md** — the full step-by-step build guide
- **PROMPTS.md** — copy-paste AI prompts for every step
- **TECH-STACK.md** — the recommended stack + alternatives
- **CHECKLIST.md** — a printable build & launch checklist

Start with **GUIDE.md**, and keep **PROMPTS.md** open beside it.
